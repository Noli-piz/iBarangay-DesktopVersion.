<?php
require "DataBase.php";
$db = new DataBase();
if (isset($_POST['Username']) && isset($_POST['Password']) && isset($_POST['Usertype'])) {
    if ($db->dbConnect()) {
        if ($db->desktopLogin($_POST['Username'], $_POST['Password'],  $_POST['Usertype'] )) {
            echo "Login Success";
        } else echo "Username or Password wrong";
    } else echo "Error: Database connection";
} else echo "All fields are required";
?>
