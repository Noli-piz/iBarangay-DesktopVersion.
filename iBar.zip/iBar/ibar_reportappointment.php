<?php
require "DataBaseConfig.php";

$dbc = new DataBaseConfig();
$host = $dbc->servername;
$user = $dbc->username;
$pwd = $dbc->password;
$db = $dbc->databasename;

$conn = mysqli_connect($host, $user, $pwd, $db);
if (!$conn) {
    die("Error in Connection: " . mysqli_connect_error());
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $Date1 = $_POST['Date1'];
    $Date2 = $_POST['Date2'];
    
    $response = array();
    $sql_query = "SELECT  a.id_appointmentreports ,u.Fullname, ap.Title, ap.Name, ap.Date AS apDate, ap.StartTime, ap.EndTime, ap.Details, a.Action AS Status, ap.Deleted ,a.Date
                    FROM tbl_appointmentreports AS a
                    LEFT JOIN tbl_users AS u ON u.id_users = a.id_users
                    LEFT JOIN tbl_appointment AS ap ON ap.id_appointment = a.id_appointment
                    WHERE a.Date >= '". $Date1 ."' AND a.Date <= '" . $Date2 . "'";


    $result = mysqli_query($conn, $sql_query);

    if (mysqli_num_rows($result) > 0) {
        $response['success'] = 1;
        $appointmentreport = array();
        while ($row = mysqli_fetch_assoc($result)) {
            array_push($appointmentreport, $row);
        }
        $response['appointmentreport'] = $appointmentreport;
    } else {
        $response['success'] = 0;
        $response['message'] = 'No Data';
    }
}
else {
    $response['success'] = 0;
    $response['message'] = 'All data is required.';
}
echo json_encode($response);
mysqli_close($conn);
?>