<?php
require "DataBaseConfig.php";

$dbc = new DataBaseConfig();
$host = $dbc->servername;
$user = $dbc->username;
$pwd = $dbc->password;
$db = $dbc->databasename;

$conn = mysqli_connect($host, $user, $pwd, $db);
if (!$conn) {
    die("Error in Connection: " . mysqli_connect_error());
}
$response = array();
$sql_query = "SELECT b.id_blotter, b.Compliant, (SELECT GROUP_CONCAT(CONCAT_WS(' ',Fname,Mname,Lname,Sname)) FROM tbl_residentinfo WHERE id_resident 
                IN (SELECT id_resident FROM tbl_assailantresident WHERE id_assailant_resident = b.id_assailant_resident AND Deleted =0)) AS Assailant1, 
                (SELECT GROUP_CONCAT(Name,' ') FROM tbl_assailantnonresident WHERE id_assailant_nonresident = b.id_assailant_nonresident AND Deleted =0) AS Assailant2 , 
                b.Details, b.Status , DATE_FORMAT(b.Date, '%Y-%m-%d') AS Date, b.Time  FROM tbl_blotterinfo AS b";

$result = mysqli_query($conn, $sql_query);

if (mysqli_num_rows($result) > 0) {
    $response['success'] = 1;
    $blotter = array();
    while ($row = mysqli_fetch_assoc($result)) {
        array_push($blotter, $row);
    }
    $response['blotter'] = $blotter;
} else {
    $response['success'] = 0;
    $response['message'] = 'No Data';
}
echo json_encode($response);
mysqli_close($conn);
?>