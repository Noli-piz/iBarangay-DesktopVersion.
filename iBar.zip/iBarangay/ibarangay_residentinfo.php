<?php
require "DataBaseConfig.php";

$dbc = new DataBaseConfig();
$host = $dbc->servername;
$user = $dbc->username;
$pwd = $dbc->password;
$db = $dbc->databasename;

$conn = mysqli_connect($host, $user, $pwd, $db);

if (mysqli_connect_errno($conn)) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

//$id = $_GET['username'];
$id = 1;
$result = mysqli_query($conn,"SELECT * FROM tbl_residentinfo WHERE id_resident = (SELECT id_resident FROM tbl_account  WHERE id_resident = '$id')");
$row = mysqli_fetch_array($result);
$data = $row[0];

if($data){
    echo $data;
}
mysqli_close($conn);
?>
