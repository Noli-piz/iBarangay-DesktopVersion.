<?php
require "DataBase.php";
$db = new DataBase();

if (isset($_POST['Username']) && isset($_POST['Fullname']) && isset($_POST['Password']) && isset($_POST['LevelOfAccess']) && isset($_POST['Status']) && isset($_POST['ID']) ) {
    if ($db->dbConnect()) {
        if ($db->updateUsers($_POST['Username'], $_POST['Fullname'], $_POST['Password'], $_POST['LevelOfAccess'], $_POST['Status'], $_POST['ID'])) {
            echo "Operation Success";
        } else echo "Operation Failed";
    } else echo "Error: Database connection";
} else echo "All fields are required";
?>
