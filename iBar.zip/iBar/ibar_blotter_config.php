<?php
require "DataBaseConfig.php";

$dbc = new DataBaseConfig();
$host = $dbc->servername;
$user = $dbc->username;
$pwd = $dbc->password;
$db = $dbc->databasename;

$response = array();
$response['host'] = $host;
$response['user'] = $user;
$response['pwd'] = $pwd;
$response['db'] = $db;

echo json_encode($response);

?>