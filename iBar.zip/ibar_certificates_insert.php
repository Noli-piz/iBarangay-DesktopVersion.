<?php
require "DataBase.php";
$db = new DataBase();

if (isset($_POST['Types']) && isset($_POST['DocFee']) && isset($_POST['DeliveryFee'])) {
    if ($db->dbConnect()) {
        if ($db->insertCertificate($_POST['Types'], $_POST['DocFee'], $_POST['DeliveryFee'])) {
            echo "Operation Success";
        } else echo "Operation Failed";
    } else echo "Error: Database connection";
} else echo "All fields are required";

?>
