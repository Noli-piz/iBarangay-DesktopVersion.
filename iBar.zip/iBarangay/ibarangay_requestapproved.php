<?php
require "DataBaseConfig.php";

$dbc = new DataBaseConfig();
$host = $dbc->servername;
$user = $dbc->username;
$pwd = $dbc->password;
$db = $dbc->databasename;

$conn = mysqli_connect($host, $user, $pwd, $db);
if (!$conn) {
    die("Error in Connection: " . mysqli_connect_error());
}
$response = array();
$Username = $_GET['Username'];

$sql_query = "SELECT c.Types , r.Purpose, r.DateOfRequest, r.Status, d.Options FROM tbl_request AS r INNER JOIN tbl_certificate AS c ON c.id_certificate = r.id_certificate INNER JOIN tbl_deliveryoption AS d ON d.id_deliveryoption = r.id_deliveryoption WHERE r.id_account = (SELECT id_account FROM tbl_account WHERE Username = '" . $Username ."') AND r.Status = 'Approved';";


$result = mysqli_query($conn, $sql_query);

if (mysqli_num_rows($result) > 0) {
    $response['success'] = 1;
    $request = array();
    while ($row = mysqli_fetch_assoc($result)) {
        array_push($request, $row);
    }
    $response['request'] = $request;
} else {
    $response['success'] = 0;
    $response['message'] = 'No Data';
}
echo json_encode($response);
mysqli_close($conn);
?>
