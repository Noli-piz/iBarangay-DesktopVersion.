<?php
require "DataBaseConfig.php";

$dbc = new DataBaseConfig();
$host = $dbc->servername;
$user = $dbc->username;
$pwd = $dbc->password;
$db = $dbc->databasename;

$conn = mysqli_connect($host, $user, $pwd, $db);
if (!$conn) {
    die("Error in Connection: " . mysqli_connect_error());
}

    $response = array();
    $sql_query = "SELECT COALESCE((SELECT COUNT(*)  FROM tbl_blotterinfo WHERE Status = 'Active'),0) AS Active,
                        (SELECT COALESCE(COUNT(*), 0) FROM tbl_blotterinfo WHERE Status = 'Settled') AS Settled,
                        (SELECT COALESCE(COUNT(*), 0) FROM tbl_blotterinfo WHERE Status = 'Scheduled') AS Scheduled,
                        (SELECT COALESCE(COUNT(*), 0) FROM tbl_residentinfo ) AS Resident,
                        (SELECT COALESCE(COUNT(*), 0) FROM tbl_residentinfo WHERE Gender = 'Male') AS Male,
                        (SELECT COALESCE(COUNT(*), 0) FROM tbl_residentinfo WHERE Gender = 'Female') AS Female,
                        (SELECT COALESCE(COUNT(*), 0) FROM tbl_residentinfo WHERE VoterStatus = 'Yes') AS Register,
                        (SELECT COALESCE(COUNT(*), 0) FROM tbl_request WHERE Status = 'Pending') AS Request,
                        (SELECT COALESCE(COUNT(*), 0) FROM tbl_account) AS TotalAccount,
                        (SELECT COALESCE(COUNT(*), 0) FROM tbl_account WHERE Status = '1') AS BannedAccount,
                        (SELECT COALESCE(COUNT(*), 0) FROM tbl_account WHERE Valid = '1') AS Validated,
                        (SELECT COALESCE(COUNT(*), 0) FROM tbl_account WHERE Valid = '0') AS NotValidated,
                        (SELECT COALESCE(COUNT(*), 0) FROM tbl_users WHERE Status = '0') AS ActiveUsers
                        FROM tbl_users LIMIT 0,1";

    $result = mysqli_query($conn, $sql_query);

    if (mysqli_num_rows($result) > 0) {
        $response['success'] = 1;
        $count = array();
        while ($row = mysqli_fetch_assoc($result)) {
            array_push($count, $row);
        }
        $response['count'] = $count;
    } else {
        $response['success'] = 0;
        $response['message'] = 'No Data';
    }
    echo json_encode($response);

mysqli_close($conn);
?>