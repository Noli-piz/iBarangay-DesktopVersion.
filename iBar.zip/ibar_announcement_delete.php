<?php
require "DataBase.php";
$db = new DataBase();

if ( isset($_POST['ID']) && isset($_POST['UserID'])) {
    if ($db->dbConnect()) {
        if ($db->deleteAnnouncement($_POST['ID'] , $_POST['UserID'])) {
            echo "Operation Success";
        } else echo "Operation Failed";
    } else echo "Error: Database connection";
} else echo "All fields are required";
?>
