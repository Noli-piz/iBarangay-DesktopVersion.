<?php
require "DataBaseConfig.php";

$dbc = new DataBaseConfig();
$host = $dbc->servername;
$user = $dbc->username;
$pwd = $dbc->password;
$db = $dbc->databasename;

$conn = mysqli_connect($host, $user, $pwd, $db);
if (!$conn) {
    die("Error in Connection: " . mysqli_connect_error());
}
$response = array();
$sql_query = "SELECT *, IF(VoterStatus='Yes', 'Registered', 'Not-Registered') AS VoterStatus ,TIMESTAMPDIFF(YEAR, Birthdate , CURDATE()) AS Age FROM tbl_residentinfo";

$result = mysqli_query($conn, $sql_query);

if (mysqli_num_rows($result) > 0) {
    $response['success'] = 1;
    $resident = array();
    while ($row = mysqli_fetch_assoc($result)) {
        array_push($resident, $row);
    }
    $response['resident'] = $resident;
} else {
    $response['success'] = 0;
    $response['message'] = 'No Data';
}
echo json_encode($response);
mysqli_close($conn);
?>