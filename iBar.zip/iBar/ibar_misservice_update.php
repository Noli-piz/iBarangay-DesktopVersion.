<?php
require "DataBase.php";
$db = new DataBase();

if( $_POST['Category'] == "Approved" ){

    
    if (isset($_POST['Quantity']) && isset($_POST['ItemName']) && isset($_POST['Status']) && isset($_POST['Deadline']) && isset($_POST['ID'])) {
        if ($db->dbConnect()) {

            if ($db->updateMisserviceApproved($_POST['Quantity'], $_POST['ItemName'], $_POST['Status'], $_POST['Deadline'], $_POST['ID'] )) {
                echo "Operation Success";
            } else echo "Operation Failed";

        } else echo "Error: Database connection";
    } else echo "All fields are required";


}elseif( $_POST['Category'] == "Disapproved" || $_POST['Category'] == "Barrowed" ){

    if (isset($_POST['Status']) && isset($_POST['ID'])) {
        if ($db->dbConnect()) {

            if ($db->updateMisserviceDisapproved($_POST['Status'], $_POST['ID'] )) {
                echo "Operation Success";
            } else echo "Operation Failed";

        } else echo "Error: Database connection";
    } else echo "All fields are required";

}elseif( $_POST['Category'] == "Barrowed" ){


}elseif( $_POST['Category'] == "Returned" ){

    if (isset($_POST['Quantity']) && isset($_POST['ItemName']) &&  isset($_POST['Status']) && isset($_POST['ID']) ) {
        if ($db->dbConnect()) {

            if ($db->updateMisserviceReturned($_POST['Quantity'], $_POST['ItemName'] ,$_POST['Status'], $_POST['ID'] )) {
                echo "Operation Success";
            } else echo "Operation Failed";

        } else echo "Error: Database connection";
    } else echo "All fields are required";

}else{
    echo "Unable to perform.";
}

?>
