<?php
require "DataBaseConfig.php";

$dbc = new DataBaseConfig();
$host = $dbc->servername;
$user = $dbc->username;
$pwd = $dbc->password;
$db = $dbc->databasename;

$conn = mysqli_connect($host, $user, $pwd, $db);
if (!$conn) {
    die("Error in Connection: " . mysqli_connect_error());
}
$response = array();
$sql_query = "SELECT res.id_resident, req.id_request, res.Fname, res.Mname, res.Lname, res.Sname, res.Birthdate, res.Gender, res.VoterStatus, (SELECT COUNT(id_assailant_resident) FROM tbl_assailantresident WHERE id_resident =res.id_resident AND Deleted =0) AS Blotter ,cer.Types , req.DateOfRequest, req.Status FROM tbl_request AS req 
INNER JOIN tbl_account AS a ON a.id_account = req.id_account 
INNER JOIN tbl_residentinfo AS res ON res.id_resident = a.id_resident 
INNER JOIN tbl_certificate AS cer ON cer.id_certificate = req.id_certificate";

$result = mysqli_query($conn, $sql_query);

if (mysqli_num_rows($result) > 0) {
    $response['success'] = 1;
    $request = array();
    while ($row = mysqli_fetch_assoc($result)) {
        array_push($request, $row);
    }
    $response['request'] = $request;
} else {
    $response['success'] = 0;
    $response['message'] = 'No Data';
}
echo json_encode($response);
mysqli_close($conn);
?>