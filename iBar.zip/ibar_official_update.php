<?php
require "DataBase.php";
$db = new DataBase();

if (isset($_POST['ID']) && isset($_POST['Fname']) && isset($_POST['Position1']) && isset($_POST['Position2'])) {
    if ($db->dbConnect()) {
        if ($db->updateOfficial($_POST['ID'], $_POST['Fname'], $_POST['Position1'], $_POST['Position2'])) {
            echo "Operation Success";
        } else echo "Operation Failed";
    } else echo "Error: Database connection";
} else echo "All fields are required";
?>
