<?php
require "DataBaseConfig.php";

class DataBase
{
    public $connect;
    public $data;
    private $sql;
    private $sql2; // for TRANSACTION
    protected $servername;
    protected $username;
    protected $password;
    protected $databasename;

    public function __construct()
    {
        $this->connect = null;
        $this->data = null;
        $this->sql = null;
        $this->sql2 = null;
        $dbc = new DataBaseConfig();
        $this->servername = $dbc->servername;
        $this->username = $dbc->username;
        $this->password = $dbc->password;
        $this->databasename = $dbc->databasename;
    }

    function dbConnect()
    {
        $this->connect = mysqli_connect($this->servername, $this->username, $this->password, $this->databasename);
        return $this->connect;
    }

    function prepareData($data)
    {
        return mysqli_real_escape_string($this->connect, stripslashes(htmlspecialchars($data)));
    }

    function logIn($table, $username, $password)
    {
        $username = $this->prepareData($username);
        $password = $this->prepareData($password);
        $this->sql = "select * from " . $table . " where username = '" . $username . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $row = mysqli_fetch_assoc($result);
        if (mysqli_num_rows($result) != 0) {
            $dbusername = $row['username'];
            $dbpassword = $row['password'];
            if($dbusername == $username && $dbpassword == $password){
            //if ($dbusername == $username && password_verify($password, $dbpassword)) {
                $login = true;
            } else $login = false;
        } else $login = false;

        return $login;
    }

    function signUp($table, $fullname, $email, $username, $password)
    {
        $fullname = $this->prepareData($fullname);
        $username = $this->prepareData($username);
        $password = $this->prepareData($password);
        $email = $this->prepareData($email);
        //$password = password_hash($password, PASSWORD_DEFAULT);
        $this->sql = "INSERT INTO " . $table . " (fullname, username, password, email) VALUES ('" . $fullname . "','" . $username . "','" . $password . "','" . $email . "')";
        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }


    // //ibarangay signup
    // function isignUp( $Username, $Password, $Email, $Status)
    // {
    //     $Username = $this->prepareData($Username);
    //     $Password = $this->prepareData($Password);
    //     $Status = $this->prepareData($Status);
    //     $Email = $this->prepareData($Email);
    //     $this->sql = "INSERT INTO tbl_account( Username, Password, id_resident, Status ) VALUES ('" . $Username . "','" . $Password . "',(SELECT MAX(id_resident) FROM tbl_residentinfo WHERE Email = '" .$Email. "'),'" . $Status ."');";
    //     if (mysqli_query($this->connect, $this->sql)) {
    //         return true;
    //     } else return false;
    // }


    //ibarangay login
    function ilogIn($table, $Username, $Password)
    {
        $Username = $this->prepareData($Username);
        $Password = $this->prepareData($Password);
        $this->sql = "select * from " . $table . " where Username = '" . $Username . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $row = mysqli_fetch_assoc($result);
        if (mysqli_num_rows($result) != 0) {
            $dbusername = $row['Username'];
            $dbpassword = $row['Password'];
            if($dbusername == $Username && $dbpassword == $Password){
                $login = true;
            } else $login = false;
        } else $login = false;

        return $login;
    }

    //ibanangay certificate
    function icertificate()
    {
        $response = array();
        $sql_query = "SELECT * FROM tbl_certificate";
        $result = mysqli_query($this->connect, $sql_query);

        if(mysqli_num_rows($result) > 0){
            $response['success'] = 1;
            $certificate = array();
            while ($row = mysqli_fetch_assoc($result)){
                array_push($certificate, $row);
            }
            $response['certificate'] = $certificate;
        }
        else{
            $response['success'] = 0;
            $response['message'] = 'No Data';
        }
        echo json_encode($response);
        mysqli_close($this->connect);
    }

    // //ibarangay signup2
    // function isignUp2($Fname, $Mname, $Lname, $Sname, $Birthplace, $Birthdate, $CivilStatus, $Gender, $id_purok, $VoterStatus, $DateOfRegistration, $ContactNo, $CedulaNo, $Email, $Image)
    // {
    //     $Fname = $this->prepareData($Fname);
    //     $Mname = $this->prepareData($Mname);
    //     $Lname = $this->prepareData($Lname);
    //     $Sname = $this->prepareData($Sname);
    //     $Birthplace = $this->prepareData($Birthplace);
    //     $Birthdate = $this->prepareData($Birthdate);
    //     $CivilStatus = $this->prepareData($CivilStatus);
    //     $Gender = $this->prepareData($Gender);
    //     $id_purok = $this->prepareData($id_purok);
    //     $VoterStatus = $this->prepareData($VoterStatus);
    //     $DateOfRegistration = $this->prepareData($DateOfRegistration);
    //     $ContactNo = $this->prepareData($ContactNo);
    //     $CedulaNo = $this->prepareData($CedulaNo);
    //     $Email = $this->prepareData($Email);
    //     $Image = $this->prepareData($Image);

    //     $this->sql ="INSERT INTO tbl_residentinfo ( Fname, Mname, Lname, Sname,Birthplace, Birthdate, CivilStatus, Gender, id_purok, VoterStatus, DateOfRegistration, ContactNo, CedulaNo, Email, Image ) VALUES('" . $Fname . "','" . $Mname . "','" . $Lname . "','" . $Sname . "','" . $Birthplace . "','" . $Birthdate . "','" . $CivilStatus . "','" . $Gender . "',(SELECT id_purok FROM tbl_purok WHERE Name = '" . $id_purok . "') ,'" . $VoterStatus ."','" . $DateOfRegistration . "','" . $ContactNo . "','" . $CedulaNo . "','" . $Email . "','" . $Image . "');";

    //     if (mysqli_query($this->connect, $this->sql)) {
    //         return true;
    //     } else return false;
    // }

    //ibarangay signup3
    function isignUp3($Username, $Password, $Status, $Fname, $Mname, $Lname, $Sname, $Birthplace, $Birthdate, $CivilStatus, $Gender, $id_purok, $VoterStatus, $DateOfRegistration, $ContactNo, $CedulaNo, $Email, $Image)
    {
        $Username = $this->prepareData($Username);
        $Password = $this->prepareData($Password);
        $Status = $this->prepareData($Status);
        $Fname = $this->prepareData($Fname);
        $Mname = $this->prepareData($Mname);
        $Lname = $this->prepareData($Lname);
        $Sname = $this->prepareData($Sname);
        $Birthplace = $this->prepareData($Birthplace);
        $Birthdate = $this->prepareData($Birthdate);
        $CivilStatus = $this->prepareData($CivilStatus);
        $Gender = $this->prepareData($Gender);
        $id_purok = $this->prepareData($id_purok);
        $VoterStatus = $this->prepareData($VoterStatus);
        $DateOfRegistration = $this->prepareData($DateOfRegistration);
        $ContactNo = $this->prepareData($ContactNo);
        $CedulaNo = $this->prepareData($CedulaNo);
        $Email = $this->prepareData($Email);
        $Image = $this->prepareData($Image);

        if($Sname == "NONE"){
            $Sname = "";
        }

        if($CedulaNo == "NONE"){
            $CedulaNo = "";
        }
        
        if($Mname == "NONE"){
            $Mname = "";
        }

        $this->sql = "INSERT INTO tbl_residentinfo ( Fname, Mname, Lname, Sname, Birthplace, Birthdate, CivilStatus, Gender, id_purok, VoterStatus, DateOfRegistration, ContactNo, CedulaNo, Email, Image ) VALUES('" . $Fname . "','" . $Mname . "','" . $Lname . "','" . $Sname . "','" . $Birthplace . "','" . $Birthdate . "','" . $CivilStatus . "','" . $Gender . "',(SELECT id_purok FROM tbl_purok WHERE Name = '" . $id_purok . "') ,'" . $VoterStatus ."','" . $DateOfRegistration . "','" . $ContactNo . "','" . $CedulaNo . "','" . $Email . "','" . $Image . "');";
        $this->sql2 = "INSERT INTO tbl_account( Username, Password, id_resident, Status ) VALUES ('" . $Username . "','" . $Password . "',(SELECT MAX(id_resident) FROM tbl_residentinfo WHERE Email = '" .$Email. "'),'" . $Status ."');";

        mysqli_begin_transaction($this->connect);
        mysqli_autocommit($this->connect, false);

        if (mysqli_query($this->connect, $this->sql) && mysqli_query($this->connect, $this->sql2))
        {
            mysqli_commit($this->connect);
            return true;
        }else{
            mysqli_rollback($this->connect);
            return false;

        }
    }

        //ibarangay Update Information
        function iUpdateInformation($Fname, $Mname, $Lname, $Sname, $Birthplace, $Birthdate, $CivilStatus, $Gender, $id_purok, $VoterStatus, $DateOfRegistration, $ContactNo, $CedulaNo, $Username, $Image)
        {
            
            $Username = $this->prepareData($Username);
            $Fname = $this->prepareData($Fname);
            $Mname = $this->prepareData($Mname);
            $Lname = $this->prepareData($Lname);
            $Sname = $this->prepareData($Sname);
            $Birthplace = $this->prepareData($Birthplace);
            $Birthdate = $this->prepareData($Birthdate);
            $CivilStatus = $this->prepareData($CivilStatus);
            $Gender = $this->prepareData($Gender);
            $id_purok = $this->prepareData($id_purok);
            $VoterStatus = $this->prepareData($VoterStatus);
            $DateOfRegistration = $this->prepareData($DateOfRegistration);
            $ContactNo = $this->prepareData($ContactNo);
            $CedulaNo = $this->prepareData($CedulaNo);
            $Image = $this->prepareData($Image);
    
            if($Sname == "NONE"){
                $Sname = "";
            }
    
            $this->sql = "UPDATE tbl_residentinfo SET Fname = '". $Fname ."', Mname='". $Mname ."', Lname ='". $Lname."', Sname='". $Sname ."', Birthplace = '". $Birthplace ."', Birthdate='".$Birthdate."',
                            CivilStatus ='". $CivilStatus ."', Gender='". $Gender ."', id_purok = (SELECT id_purok FROM tbl_purok WHERE Name = '" . $id_purok . "'), VoterStatus='". $VoterStatus ."', 
                            DateOfRegistration='".$DateOfRegistration."', ContactNo='".$ContactNo."', CedulaNo='". $CedulaNo."', Image='".$Image."'  
                            WHERE id_resident= (SELECT id_resident FROM tbl_account WHERE Username = '" . $Username. "')"; 
           
            if (mysqli_query($this->connect, $this->sql))
            {
                return true;
            }else{
                return false;
            }
        }

    //Check Username if already Exist
    function checkUsername($Username)
    {
        $Username = $this->prepareData($Username);

        $this->sql = "SELECT Username FROM tbl_account WHERE Username = '" . $Username . "'";
        $result = mysqli_query($this->connect, $this->sql);

        if (mysqli_num_rows($result) == 0) {
            return true;
        } else return false;
    }

    //Insert Request
    function insertRequest($Username, $Certificate ,$Purpose,$DateOfRequest,$Status,$deliveryoption){
        $Username = $this->prepareData($Username);
        $Certificate = $this->prepareData($Certificate);
        $Purpose = $this->prepareData($Purpose);
        $DateOfRequest = $this->prepareData($DateOfRequest);
        $Status = $this->prepareData($Status);
        $deliveryoption = $this->prepareData($deliveryoption);

        $this->sql = "INSERT INTO tbl_request(id_account, id_certificate, Purpose, DateOfRequest, Status, id_deliveryoption) VALUES( (SELECT id_account FROM tbl_account WHERE Username = '" . $Username . "') , (SELECT id_certificate FROM tbl_certificate WHERE Types = '" . $Certificate . "' ) , '" . $Purpose . "' , '" . $DateOfRequest . "' , '" . $Status ."' , (SELECT id_deliveryoption FROM tbl_deliveryoption WHERE Options = '" . $deliveryoption . "'));";

        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

    //Insert Request
    function insertRequestMisSer($Username, $Item ,$Quantity ,$Purpose,$DateOfRequest,$Status,$deliveryoption){
        $Username = $this->prepareData($Username);
        $Item = $this->prepareData($Item);
        $Quantity = $this->prepareData($Quantity);
        $Purpose = $this->prepareData($Purpose);
        $DateOfRequest = $this->prepareData($DateOfRequest);
        $Status = $this->prepareData($Status);
        $deliveryoption = $this->prepareData($deliveryoption);

        $this->sql = "INSERT INTO tbl_misservices(id_account, id_items, Quantity, Purpose, Status, DateOfRequest, id_deliveryoption) VALUES( (SELECT id_account FROM tbl_account WHERE Username = '" . $Username . "'), (SELECT id_items FROM tbl_items WHERE ItemName = '" . $Item . "' ) , '" . $Quantity . "', '" . $Purpose ."', '" . $Status . "', '" . $DateOfRequest . "', (SELECT id_deliveryoption FROM tbl_deliveryoption WHERE Options = '" . $deliveryoption . "'));";

        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

    //Insert Verification
    function insertVerification($Username, $IdImgUrl ,$IdAndFaceImgUrl ){
        $Username = $this->prepareData($Username);
        $IdImgUrl = $this->prepareData($IdImgUrl);
        $IdAndFaceImgUrl = $this->prepareData($IdAndFaceImgUrl);

        $this->sql = "INSERT INTO tbl_validation(img_idcloseup, img_facewithid) VALUES( '". $IdImgUrl ."', '".$IdAndFaceImgUrl."');";
        $this->sql2 = "UPDATE tbl_account SET id_validation = (SELECT MAX(id_validation) FROM tbl_validation) WHERE Username='" . $Username . "'";

        mysqli_begin_transaction($this->connect);
        mysqli_autocommit($this->connect, false);

        if (mysqli_query($this->connect, $this->sql) && mysqli_query($this->connect, $this->sql2))
        {
            mysqli_commit($this->connect);
            return true;
        }else{
            mysqli_rollback($this->connect);
            return false;

        }
    }

}
?>
