<?php
require "DataBase.php";
$db = new DataBase();

// if (isset($_POST['ID'], $_POST['Title']) && isset($_POST['Name']) && isset($_POST['Date']) && isset($_POST['StartTime']) && isset($_POST['EndTime']) && isset($_POST['Details']) && isset($_POST['Status']) && isset($_POST['UserID']) ) {
//     if ($db->dbConnect()) {
//         if ($db->updateAppointment($_POST['ID'], $_POST['Title'], $_POST['Name'], $_POST['Date'],$_POST['StartTime'], $_POST['EndTime'], $_POST['Details'], $_POST['Status'], $_POST['UserID'] )) {
//             echo "Operation Success";
//         } else echo "Operation Failed";
//     } else echo "Error: Database connection";
// } else echo "All fields are required";

if (isset($_POST['content'], $_POST['Title']) && isset($_POST['Name']) && isset($_POST['Date']) && isset($_POST['StartTime']) && isset($_POST['EndTime']) && isset($_POST['Details']) && isset($_POST['Status']) && isset($_POST['UserID']) && isset($_POST['StartTimeFilter']) && isset($_POST['EndTimeFilter']) ) {
    if ($db->dbConnect()) {
        if ($db->updateAppointment($_POST['content'], $_POST['Title'], $_POST['Name'], $_POST['Date'],$_POST['StartTime'], $_POST['EndTime'], $_POST['Details'], $_POST['Status'], $_POST['UserID'], $_POST['StartTimeFilter'], $_POST['EndTimeFilter'])) {
            echo "Operation Success";
        } else echo "Operation Failed";
    } else echo "Error: Database connection";
} else echo "All fields are required";

?>
