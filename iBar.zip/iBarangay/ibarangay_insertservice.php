<?php
require "DataBase.php";
$db = new DataBase();
if (isset($_POST['Username']) && isset($_POST['Item']) && isset($_POST['Quantity']) && isset($_POST['Purpose']) && isset($_POST['DateOfRequest']) && isset($_POST['Status']) && isset($_POST['deliveryoption'])) {
    if ($db->dbConnect()) {
        if ($db->insertRequestMisSer($_POST['Username'], $_POST['Item'], $_POST['Quantity'], $_POST['Purpose'], $_POST['DateOfRequest'], $_POST['Status'], $_POST['deliveryoption'])) {
            echo "Operation Success";
        } else echo "Operation Failed";
    } else echo "Error: Database connection";
} else echo "All fields are required";
?>
