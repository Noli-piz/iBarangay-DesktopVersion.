<?php
require "DataBaseConfig.php";

$dbc = new DataBaseConfig();
$host = $dbc->servername;
$user = $dbc->username;
$pwd = $dbc->password;
$db = $dbc->databasename;

$conn = mysqli_connect($host, $user, $pwd, $db);
if (!$conn) {
    die("Error in Connection: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ID = $_POST['ID'];
    $Category = $_POST['Category'];

    if(isset($_POST['ID']) && isset($_POST['Category'])){
        $response = array();
        $sql_query = "SELECT a.id_account, res.id_resident, req.id_request, res.Fname, res.Mname, res.Lname, res.Sname, res.Birthdate, res.Gender, IF(res.VoterStatus='Yes', 'Registered', 'Not-Registered') AS VoterStatus, (SELECT COUNT(id_assailant_resident) FROM tbl_assailantresident WHERE id_resident =res.id_resident AND Deleted =0) AS Blotter ,cer.Types , req.DateOfRequest, req.Status FROM tbl_request AS req 
        INNER JOIN tbl_account AS a ON a.id_account = req.id_account 
        INNER JOIN tbl_residentinfo AS res ON res.id_resident = a.id_resident 
        INNER JOIN tbl_certificate AS cer ON cer.id_certificate = req.id_certificate";

         if($Category== "Name"){
            $sql_query = "SELECT a.id_account ,res.id_resident, req.id_request, res.Fname, res.Mname, res.Lname, res.Sname, res.Birthdate, res.Gender, IF(res.VoterStatus='Yes', 'Registered', 'Not-Registered') AS VoterStatus, (SELECT COUNT(id_assailant_resident) FROM tbl_assailantresident WHERE id_resident =res.id_resident AND Deleted =0) AS Blotter ,cer.Types , req.DateOfRequest, req.Status FROM tbl_request AS req 
            INNER JOIN tbl_account AS a ON a.id_account = req.id_account 
            INNER JOIN tbl_residentinfo AS res ON res.id_resident = a.id_resident 
            INNER JOIN tbl_certificate AS cer ON cer.id_certificate = req.id_certificate 
            WHERE res.Fname LIKE '". $ID ."' OR res.Mname LIKE '". $ID ."' OR res.Lname LIKE '". $ID ."' ";
         }elseif($Category == "ID"){
            $sql_query = "SELECT a.id_account, res.id_resident, req.id_request, res.Fname, res.Mname, res.Lname, res.Sname, res.Birthdate, res.Gender, IF(res.VoterStatus='Yes', 'Registered', 'Not-Registered') AS VoterStatus, (SELECT COUNT(id_assailant_resident) FROM tbl_assailantresident WHERE id_resident =res.id_resident AND Deleted =0) AS Blotter ,cer.Types , req.DateOfRequest, req.Status FROM tbl_request AS req 
            INNER JOIN tbl_account AS a ON a.id_account = req.id_account 
            INNER JOIN tbl_residentinfo AS res ON res.id_resident = a.id_resident 
            INNER JOIN tbl_certificate AS cer ON cer.id_certificate = req.id_certificate 
            WHERE req.id_request='". $ID ."'";
         }


        $result = mysqli_query($conn, $sql_query);

        if (mysqli_num_rows($result) > 0) {
            $response['success'] = 1;
            $request = array();
            while ($row = mysqli_fetch_assoc($result)) {
                array_push($request, $row);
            }
            $response['request'] = $request;
        } else {
            $response['success'] = 0;
            $response['message'] = 'No Result';
        }
        echo json_encode($response);
    }
    
}
else{
        $response['success'] = 0;
        $response['message'] = 'All Fields Required';
}
mysqli_close($conn);
?>