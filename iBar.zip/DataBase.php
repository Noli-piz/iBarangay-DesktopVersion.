<?php
require "DataBaseConfig.php";

class DataBase
{
    public $connect;
    public $data;
    private $sql;
    private $sql2; // for TRANSACTION
    protected $servername;
    protected $username;
    protected $password;
    protected $databasename;

    public function __construct()
    {
        $this->connect = null;
        $this->data = null;
        $this->sql = null;
        $this->sql2 = null;
        $dbc = new DataBaseConfig();
        $this->servername = $dbc->servername;
        $this->username = $dbc->username;
        $this->password = $dbc->password;
        $this->databasename = $dbc->databasename;
    }

    function dbConnect()
    {
        $this->connect = mysqli_connect($this->servername, $this->username, $this->password, $this->databasename);
        return $this->connect;
    }

    function prepareData($data)
    {
        return mysqli_real_escape_string($this->connect, stripslashes(htmlspecialchars($data)));
    }

    // Desktop Login
    function desktopLogin($Username, $Password, $Usertype){
        $Username = $this->prepareData($Username);
        $Password = $this->prepareData($Password);
        $Usertype = $this->prepareData($Usertype);

        $this->sql ="SELECT * FROM tbl_users WHERE Username = '" . $Username . "' AND Password= '" . $Password . "' AND Status = 0 AND LevelOfAccess= '" . $Usertype ."'";

        $result = mysqli_query($this->connect, $this->sql);
        $row = mysqli_fetch_assoc($result);
        if (mysqli_num_rows($result) != 0) {
            $dbusername = $row['Username'];
            $dbpassword = $row['Password'];
            if($dbusername == $Username && $dbpassword == $Password){
            //if ($dbusername == $username && password_verify($password, $dbpassword)) {
                $login = true;
            } else $login = false;
        } else $login = false;

        return $login;
    }

    //Check if User is banned or disable
    function userIsBanned($Username){
        $Username = $this->prepareData($Username);

        $this->sql ="SELECT * FROM tbl_users WHERE Username = '" . $Username . "' AND Status = 1 ";

        $result = mysqli_query($this->connect, $this->sql);
        $row = mysqli_fetch_assoc($result);
        if (mysqli_num_rows($result) != 0) {
            $login = true;
        } else $login = false;

        return $login;
    }

    //Insert Resident Information
    function insertResidentInfo($Fname, $Mname, $Lname, $Sname, $Birthplace, $Birthdate, $CivilStatus, 
    $Gender, $id_purok, $VoterStatus, $DateOfRegistration, $ContactNo, $CedulaNo, $Email, $Image ,$HouseAndStreet )
    {
        $Fname = $this->prepareData($Fname);
        $Mname = $this->prepareData($Mname);
        $Lname = $this->prepareData($Lname);
        $Sname = $this->prepareData($Sname);
        $Birthplace = $this->prepareData($Birthplace);
        $Birthdate = $this->prepareData($Birthdate);
        $CivilStatus = $this->prepareData($CivilStatus);
        $Gender = $this->prepareData($Gender);
        $id_purok = $this->prepareData($id_purok);
        $VoterStatus = $this->prepareData($VoterStatus);
        $DateOfRegistration = $this->prepareData($DateOfRegistration);
        $ContactNo = $this->prepareData($ContactNo);
        $CedulaNo = $this->prepareData($CedulaNo);
        $Email = $this->prepareData($Email);
        $Image = $this->prepareData($Image);
        $HouseAndStreet = $this->prepareData($HouseAndStreet);

        $this->sql = "INSERT INTO tbl_residentinfo ( Fname, Mname, Lname, Sname, Birthplace, Birthdate, CivilStatus, Gender, id_purok, VoterStatus, DateOfRegistration, ContactNo, CedulaNo, Email, Image, HouseNoAndStreet ) 
                VALUES('" . $Fname . "','" . $Mname . "','" . $Lname . "','" . $Sname . "','" . $Birthplace . "','" . $Birthdate . "','" . $CivilStatus . "','" . $Gender . "',
                (SELECT id_purok FROM tbl_purok WHERE Name = '" . $id_purok . "') ,'" . $VoterStatus ."','" . $DateOfRegistration . "','" . $ContactNo . "','" . $CedulaNo . "',
                '" . $Email . "','" . $Image . "', '".$HouseAndStreet."');";

        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

    function updateResidentInfo($ID, $Fname, $Mname, $Lname, $Sname, $Birthplace, $Birthdate, $CivilStatus, 
    $Gender, $id_purok, $VoterStatus, $DateOfRegistration, $ContactNo, $CedulaNo, $Email, $Image, $HouseAndStreet )
    {
        $ID = $this->prepareData($ID);
        $Fname = $this->prepareData($Fname);
        $Mname = $this->prepareData($Mname);
        $Lname = $this->prepareData($Lname);
        $Sname = $this->prepareData($Sname);
        $Birthplace = $this->prepareData($Birthplace);
        $Birthdate = $this->prepareData($Birthdate);
        $CivilStatus = $this->prepareData($CivilStatus);
        $Gender = $this->prepareData($Gender);
        $id_purok = $this->prepareData($id_purok);
        $VoterStatus = $this->prepareData($VoterStatus);
        $DateOfRegistration = $this->prepareData($DateOfRegistration);
        $ContactNo = $this->prepareData($ContactNo);
        $CedulaNo = $this->prepareData($CedulaNo);
        $Email = $this->prepareData($Email);
        $Image = $this->prepareData($Image);
        $HouseAndStreet = $this->prepareData($HouseAndStreet);

        $this->sql = "UPDATE tbl_residentinfo SET Fname = '". $Fname ."', Mname='". $Mname ."', Lname ='". $Lname."', Sname='". $Sname ."', Birthplace = '". $Birthplace ."', Birthdate='".$Birthdate."',
                            CivilStatus ='". $CivilStatus ."', Gender='". $Gender ."', id_purok = (SELECT id_purok FROM tbl_purok WHERE Name = '" . $id_purok . "'), VoterStatus='". $VoterStatus ."', 
                            DateOfRegistration='".$DateOfRegistration."', ContactNo='".$ContactNo."', CedulaNo='". $CedulaNo."', Image='".$Image."', HouseNoAndStreet = '".$HouseAndStreet."'  
                            WHERE id_resident= '". $ID ."'"; 
    
        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
        
    }

    //Insert Announcement
    function insertAnnouncement($Subject, $Details ,$Date,$Level, $UserID){
        $Subject = $this->prepareData($Subject);
        $Date = $this->prepareData($Date);
        $Level = $this->prepareData($Level);
        $Details = $this->prepareData($Details);
        $UserID = $this->prepareData($UserID);

        $this->sql ="INSERT INTO tbl_announcement(Subject, Date, Level, id_alertlevel, Details, Deleted) VALUES( '" . $Subject . "','" . $Date ."','" . $Level . "', (SELECT id_alertlevel FROM tbl_alertlevel WHERE LevelName = '" . $Level . "') ,'" . $Details ."','False' )";
        $this->sql2 ="INSERT INTO tbl_announcementreports( id_announcement, ProcessedBy ,Subject, Date, Level, Details, Action ,DateModified) 
                    VALUES( (SELECT MAX(id_announcement) FROM tbl_announcement), '". $UserID ."' ,'" . $Subject . "','" . $Date ."','" . $Level . "', '" . $Details ."','Insert', CURDATE())";
        
        mysqli_begin_transaction($this->connect);
        mysqli_autocommit($this->connect, false);

        if (mysqli_query($this->connect, $this->sql) && mysqli_query($this->connect, $this->sql2))
        {
            mysqli_commit($this->connect);
            return true;
        } else
        { 
            mysqli_rollback($this->connect);
            return false;
        }
    }

    //Update Announcement
    function updateAnnouncement($ID ,$Subject, $Details ,$Date,$Level, $UserID){
        $ID = $this->prepareData($ID);
        $Subject = $this->prepareData($Subject);
        $Details = $this->prepareData($Details);
        $Date = $this->prepareData($Date);
        $Level = $this->prepareData($Level);
        $UserID = $this->prepareData($UserID);


        $this->sql ="UPDATE tbl_announcement SET Subject='" . $Subject . "', Date='" . $Date ."', Level='". $Level . "', id_alertlevel = (SELECT id_alertlevel FROM tbl_alertlevel WHERE LevelName = '" . $Level . "') ,Details='" . $Details ."' WHERE id_announcement ='" . $ID . "'";
        $this->sql2 ="INSERT INTO tbl_announcementreports( id_announcement, ProcessedBy ,Subject, Date, Level, Details, Action ,DateModified) 
                        VALUES( '". $ID ."', '". $UserID ."' ,'" . $Subject . "','" . $Date ."','" . $Level . "', '" . $Details ."','Update', CURDATE())";


        mysqli_begin_transaction($this->connect);
        mysqli_autocommit($this->connect, false);

        if (mysqli_query($this->connect, $this->sql) && mysqli_query($this->connect, $this->sql2))
        {
            mysqli_commit($this->connect);
            return true;
        } else
        { 
            mysqli_rollback($this->connect);
            return false;
        }
    }

    //Delete Announcement
    function deleteAnnouncement($ID, $UserID ){
        $ID = $this->prepareData($ID);
        $UserID = $this->prepareData($UserID);

        $this->sql ="UPDATE tbl_announcement SET Deleted='1' WHERE id_announcement ='" . $ID . "'";
        $this->sql2 ="INSERT INTO `tbl_announcementreports`(`id_announcement`, `ProcessedBy`, `Subject`, `Date`, `Level`, `Details`, `Action`, `DateModified`) 
        SELECT id_announcement,'".$UserID."',Subject,Date, Level, Details, 'Delete', CURDATE() FROM tbl_announcement WHERE id_announcement = '".$ID."' LIMIT 0,1";

        if (mysqli_query($this->connect, $this->sql) && mysqli_query($this->connect, $this->sql2))
        {
            mysqli_commit($this->connect);
            return true;
        } else
        { 
            mysqli_rollback($this->connect);
            return false;
        }
    }

    //Insert Official
    function insertOfficial($Fname,$Position1,$Position2){
        $Fname = $this->prepareData($Fname);
        $Position1 = $this->prepareData($Position1);
        $Position2 = $this->prepareData($Position2);

        $this->sql ="INSERT INTO tbl_officials(Fname, Position1, Position2, Deleted) VALUES( '" . $Fname . "','" . $Position1 ."','" . $Position2 . "', 'False' )";
        
        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

    //Update Official
    function updateOfficial( $ID, $Fname,$Position1,$Position2){
        $ID = $this->prepareData($ID);
        $Fname = $this->prepareData($Fname);
        $Position1 = $this->prepareData($Position1);
        $Position2 = $this->prepareData($Position2);

        $this->sql ="Update tbl_officials SET Fname = '" . $Fname . "', Position1 = '" . $Position1 ."',  Position2 = '" . $Position2 . "' WHERE id_officials = '" . $ID . "'";
        
        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

    //Delete Official
    function deleteOfficial($ID){
        $ID = $this->prepareData($ID);

        $this->sql ="UPDATE tbl_officials SET Deleted='1' WHERE id_officials ='" . $ID . "'";
        
        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

    //Insert Appointment
    function insertAppointment($Title, $Name, $Date, $StartTime, $EndTime, $Details, $Status, $UserID){
        $Title = $this->prepareData($Title);
        $Name = $this->prepareData($Name);
        $Date = $this->prepareData($Date);
        $StartTime = $this->prepareData($StartTime);
        $EndTime = $this->prepareData($EndTime);
        $Details = $this->prepareData($Details);
        $Status = $this->prepareData($Status);

        $UserID = $this->prepareData($UserID);

        $this->sql ="INSERT INTO tbl_appointment(Title, Name, Date, StartTime, EndTime, Details, Status)  
                        VALUES( '" . $Title . "' , '" . $Name . "', '" . $Date . "', '". $StartTime ."', '" . $EndTime ."', '" .$Details. "', '" . $Status ."')";
        
        $this->sql2 = "INSERT INTO tbl_appointmentreports(id_users, id_appointment, Date, Action) 
            VALUES( '". $UserID ."', (SELECT MAX(id_appointment) FROM tbl_appointment), NOW(), 'Insert')";

        mysqli_begin_transaction($this->connect);
        mysqli_autocommit($this->connect, false);

        if (mysqli_query($this->connect, $this->sql) && mysqli_query($this->connect, $this->sql2))
        {
            mysqli_commit($this->connect);
            return true;
        } else
        { 
            mysqli_rollback($this->connect);
            return false;
        }
    }

    //Update Appointment
    function updateAppointment($ID, $Title, $Name, $Date, $StartTime, $EndTime, $Details, $Status, $UserID, $StartTimeFilter, $EndTimeFilter){
        $ID = $this->prepareData($ID);
        $Title = $this->prepareData($Title);
        $Name = $this->prepareData($Name);
        $Date = $this->prepareData($Date);
        $StartTime = $this->prepareData($StartTime);
        $EndTime = $this->prepareData($EndTime);
        $Details = $this->prepareData($Details);
        $Status = $this->prepareData($Status);

        //For Filter
        $StartTimeFilter = $this->prepareData($StartTimeFilter);
        $EndTimeFilter = $this->prepareData($EndTimeFilter);

        $UserID = $this->prepareData($UserID);

        //$this->sql ="UPDATE tbl_appointment SET Title = '" . $Title . "' , Name = '" . $Name . "', Date = '" . $Date . "', StartTime = '". $StartTime ."', EndTime = '" . $EndTime ."', Details = '" .$Details. "', Status = '" . $Status ."' WHERE id_appointment ='". $ID."'";
        
        $this->sql ="UPDATE tbl_appointment 
            SET Title = '" . $Title . "' , Name = '" . $Name . "', Date = '" . $Date . "', StartTime = '". $StartTime ."', EndTime = '" . $EndTime ."', Details = '" .$Details. "', Status = '" . $Status ."' 
            WHERE CONCAT('Title: ', Title, '\nName: ', Name, '\nDetails: ', Details) = '". $ID ."' 
            AND StartTime = '".$StartTimeFilter."' AND EndTime = '". $EndTimeFilter ."' ";
        
        $this->sql2 = "INSERT INTO tbl_appointmentreports(id_users, id_appointment, Date, Action) 
            VALUES( '". $UserID ."', '". $ID ."', NOW(), 'Update')";

        mysqli_begin_transaction($this->connect);
        mysqli_autocommit($this->connect, false);

        if (mysqli_query($this->connect, $this->sql) && mysqli_query($this->connect, $this->sql2))
        {
            mysqli_commit($this->connect);
            return true;
        } else
        { 
            mysqli_rollback($this->connect);
            return false;
        }
    }

    //Delete Appointment
    function deleteAppointment($ID, $UserID, $StartTimeFilter, $EndTimeFilter){
        $ID = $this->prepareData($ID);
        $UserID = $this->prepareData($UserID);

        //For Filter
        $StartTimeFilter = $this->prepareData($StartTimeFilter);
        $EndTimeFilter = $this->prepareData($EndTimeFilter);

        //$this->sql ="UPDATE tbl_appointment SET Deleted='1' WHERE id_appointment ='" . $ID . "'";
        $this->sql ="UPDATE tbl_appointment SET Deleted='1' WHERE CONCAT('Title: ', Title, '\nName: ', Name, '\nDetails: ', Details) = '". $ID ."' 
        AND StartTime = '".$StartTimeFilter."' AND EndTime = '". $EndTimeFilter ."'";
        

        $this->sql2 = "INSERT INTO tbl_appointmentreports(id_users, id_appointment, Date, Action) 
            VALUES( '". $UserID ."', '". $ID ."', NOW(), 'Delete')";

        mysqli_begin_transaction($this->connect);
        mysqli_autocommit($this->connect, false);

        if (mysqli_query($this->connect, $this->sql) && mysqli_query($this->connect, $this->sql2))
        {
            mysqli_commit($this->connect);
            return true;
        } else
        { 
            mysqli_rollback($this->connect);
            return false;
        }
    }

    //Update Request
    function updateRequest($ID, $Status, $UserID, $Note ) {
        $ID = $this->prepareData($ID);
        $Status = $this->prepareData($Status);
        $UserID = $this->prepareData($UserID);
        $Note = $this->prepareData($Note);

        if($Note == "NONE"){
            $Note ="";
        }

        $this->sql ="UPDATE tbl_request SET Status='" . $Status ."', Note='".$Note."' WHERE id_request ='" . $ID . "'";
        $this->sql2 ="INSERT INTO tbl_requestsreports(id_users, id_request, Date, Status) VALUES( '". $UserID ."', '". $ID ."', NOW(), '". $Status ."')";
        

        mysqli_begin_transaction($this->connect);
        mysqli_autocommit($this->connect, false);

        if (mysqli_query($this->connect, $this->sql) && mysqli_query($this->connect, $this->sql2))
        {
            mysqli_commit($this->connect);
            return true;
        } else
        { 
            mysqli_rollback($this->connect);
            return false;
        }
    }

    //Insert User Management
    function insertUsers($Username, $Fullname, $Password, $LevelOfAccess){
        $Username = $this->prepareData($Username);
        $Fullname = $this->prepareData($Fullname);
        $Password = $this->prepareData($Password);
        $LevelOfAccess = $this->prepareData($LevelOfAccess);

        $this->sql ="INSERT INTO tbl_users(Username, Fullname, Password,  LevelOfAccess, Status) VALUES('". $Username ."', '". $Fullname ."', '". $Password ."', '". $LevelOfAccess ."', '0')";
        
        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

    //Update User Management
    function updateUsers($Username, $Fullname, $Password, $LevelOfAccess, $Status, $ID){
        $Username = $this->prepareData($Username);
        $Fullname = $this->prepareData($Fullname);
        $Password = $this->prepareData($Password);
        $LevelOfAccess = $this->prepareData($LevelOfAccess);
        $Status = $this->prepareData($Status);
        $ID = $this->prepareData($ID);

        $this->sql ="UPDATE tbl_users SET Username= '". $Username ."', Password = '". $Password ."', Fullname ='". $Fullname ."', LevelOfAccess='". $LevelOfAccess ."',Status='". $Status ."' WHERE id_users = '".$ID."'";
        
        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }
    

    //Update Account Management
    function updateAccount($Username, $Password, $Status, $ID, $Valid){
        $Username = $this->prepareData($Username);
        $Password = $this->prepareData($Password);
        $Status = $this->prepareData($Status);
        $ID = $this->prepareData($ID);
        $Valid = $this->prepareData($Valid);

        if($Valid == "Validated"){
            $Valid = "1";
        }else{
            $Valid = "0";
        }

        $this->sql = "UPDATE tbl_account SET Username= '". $Username ."', Password ='". $Password ."' , Status= '" . $Status . "', Valid = '". $Valid ."' WHERE id_account = '". $ID."'";
        
        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

    //Update Miscleaneous Services = Approved
    function updateMisserviceApproved($Quantity, $ItemName, $Status , $Deadline, $ID, $Note){
        $Quantity = $this->prepareData($Quantity);
        $ItemName = $this->prepareData($ItemName);
        $Status = $this->prepareData($Status);
        $Deadline = $this->prepareData($Deadline);
        $ID = $this->prepareData($ID);
        $Note = $this->prepareData($Note);

        if($Note == "NONE"){
            $Note = "";
        }

        $this->sql = "UPDATE tbl_items SET Quantity = Quantity - '". $Quantity ."' WHERE ItemName= '". $ItemName ."'";
        $this->sql2 = "UPDATE tbl_misservices SET Status = '". $Status ."', Deadline = '". $Deadline ."', Note='". $Note ."' WHERE id_misservices = '" . $ID ."'";
        

        mysqli_begin_transaction($this->connect);
        mysqli_autocommit($this->connect, false);

        if (mysqli_query($this->connect, $this->sql) && mysqli_query($this->connect, $this->sql2))
        {
            mysqli_commit($this->connect);
            return true;
        } else
        { 
            mysqli_rollback($this->connect);
            return false;
        }
    }

    //Update Miscleaneous Services = Returned
    function updateMisserviceReturned($Quantity, $ItemName, $Status, $ID, $Note){
        $Quantity = $this->prepareData($Quantity);
        $ItemName = $this->prepareData($ItemName);
        $Status = $this->prepareData($Status);
        $ID = $this->prepareData($ID);
        $Note = $this->prepareData($Note);

        if($Note == "NONE"){
            $Note = "";
        }

        $this->sql = "UPDATE tbl_items SET Quantity = Quantity + '" . $Quantity . "' WHERE ItemName= '" . $ItemName . "'";
        $this->sql2 = "UPDATE tbl_misservices SET Status = '". $Status ."', Note ='".$Note."' WHERE id_misservices ='". $ID ."'";
        
        mysqli_begin_transaction($this->connect);
        mysqli_autocommit($this->connect, false);

        if (mysqli_query($this->connect, $this->sql) && mysqli_query($this->connect, $this->sql2))
        {
            mysqli_commit($this->connect);
            return true;
        } else
        { 
            mysqli_rollback($this->connect);
            return false;
        }
    }

        //Update Miscleaneous Services = Disapproved
    function updateMisserviceDisapproved($Status, $ID, $Note){
        $Status = $this->prepareData($Status);
        $ID = $this->prepareData($ID);
        $Note = $this->prepareData($Note);

        if($Note == "NONE"){
            $Note = "";
        }

        $this->sql = "UPDATE tbl_misservices SET Status = '" . $Status . "', Note ='" . $Note . "' WHERE id_misservices ='". $ID ."'";

        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

        //Insert Issuance Reports
    function insertIssuanceReports($UserID, $Types, $ResidentID, $Purpose){
        $UserID = $this->prepareData($UserID);
        $Types = $this->prepareData($Types);
        $ResidentID = $this->prepareData($ResidentID);
        $Purpose = $this->prepareData($Purpose);

        $this->sql = "INSERT INTO tbl_issuancereports(id_users, id_certificate, id_resident, Purpose, Date) 
        VALUES( '". $UserID ."', (SELECT id_certificate FROM tbl_certificate WHERE Types = '". $Types ."'), '". $ResidentID. "', '". $Purpose ."', NOW())";

        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

        //Insert Appointment Reports
    function insertAppointmentReports($UserID, $AppointmentID){
        $UserID = $this->prepareData($UserID);
        $AppointmentID = $this->prepareData($AppointmentID);

        $this->sql = "INSERT INTO tbl_appointmentreports(id_users, id_appointment, Date) 
        VALUES( '". $UserID ."', '". $AppointmentID ."', NOW())";

        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

        //Insert Request Reports
    function insertRequestReports($UserID, $RequestID){
        $UserID = $this->prepareData($UserID);
        $RequestID = $this->prepareData($RequestID);

        $this->sql = "INSERT INTO tbl_requestsreports(id_users, id_request, Date) 
        VALUES( '". $UserID ."', '". $RequestID ."', NOW())";

        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

        //
        //
        //
        //
        //
        //

        //Insert Alert Level
    function insertAlertLevel($LevelName, $ImageLocation){
        $LevelName = $this->prepareData($LevelName);
        $ImageLocation = $this->prepareData($ImageLocation);

        $this->sql = "INSERT INTO tbl_alertlevel(LevelName, ImageLocation) VALUES( '". $LevelName ."', '". $ImageLocation ."')";

        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

        //Update Alert Level
    function updateAlertLevel($ID ,$LevelName, $ImageLocation){
        $ID = $this->prepareData($ID);
        $LevelName = $this->prepareData($LevelName);
        $ImageLocation = $this->prepareData($ImageLocation);

        $this->sql = "UPDATE tbl_alertlevel SET LevelName ='". $LevelName ."', ImageLocation = '". $ImageLocation ."' WHERE id_alertlevel = '". $ID ."'";

        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

        //Delete Alert Level
    function deleteAlertLevel($ID){
        $ID = $this->prepareData($ID);

        $this->sql = "UPDATE tbl_alertlevel SET Deleted ='1' WHERE id_alertlevel = '". $ID ."'";

        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

        //Insert Purok
    function insertPurok($Purok){
        $Purok = $this->prepareData($Purok);

        $this->sql = "INSERT INTO tbl_purok(Name) VALUES( '". $Purok ."')";

        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

        //Update Purok
    function updatePurok($ID ,$Purok){
        $ID = $this->prepareData($ID);
        $Purok = $this->prepareData($Purok);

        $this->sql = "UPDATE tbl_purok SET Name = '". $Purok ."' WHERE id_purok = '". $ID ."'";

        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }
        
        //Delete Purok
    function deletePurok($ID){
        $ID = $this->prepareData($ID);

        $this->sql = "UPDATE tbl_purok SET Deleted = '1' WHERE id_purok = '". $ID ."'";

        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

        //Insert Items
    function insertItems($ItemName, $Quantity, $DeliveryFee){
        $ItemName = $this->prepareData($ItemName);
        $Quantity = $this->prepareData($Quantity);
        $DeliveryFee = $this->prepareData($DeliveryFee);

        $this->sql = "INSERT INTO tbl_items(ItemName, Quantity, TotalQuantity, DeliveryFee) VALUES( '". $ItemName ."', '". $Quantity ."', '". $Quantity ."', '". $DeliveryFee ."' )";

        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

         //Update Items
    function updateItems($ID ,$ItemName, $Quantity, $DeliveryFee){
        $ID = $this->prepareData($ID);
        $ItemName = $this->prepareData($ItemName);
        $Quantity = $this->prepareData($Quantity);
        $DeliveryFee = $this->prepareData($DeliveryFee);

        $this->sql = "UPDATE tbl_items SET ItemName='".$ItemName."', Quantity='". $Quantity ."', DeliveryFee ='". $DeliveryFee ."'  WHERE id_items = '".$ID."'";

        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

        //Delete Items
    function deleteItems($ID){
        $ID = $this->prepareData($ID);

        $this->sql = "UPDATE tbl_items SET Deleted = '1'  WHERE id_items = '" . $ID . "'";

        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

        //Insert Civil Stat
    function insertCivilStat($Types){
        $Types = $this->prepareData($Types);

        $this->sql = "INSERT INTO tbl_civilstatus (Types) VALUES( '". $Types ."')";

        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

         //Update Civil Stat
    function updateCivilStat( $ID , $Types){
        $ID = $this->prepareData($ID);
        $Types = $this->prepareData($Types);

        $this->sql = "UPDATE tbl_civilstatus SET Types='". $Types ."' WHERE id_civilstatus = '". $ID ."'";

        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }


         //Delete Civil Stat
    function deleteCivilStat($ID){
        $ID = $this->prepareData($ID);

        $this->sql = "UPDATE tbl_civilstatus SET Deleted ='1' WHERE id_civilstatus = '". $ID ."'";

        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

        //Insert Delivery Option
    function insertDeliveryOption($Options){
        $Options = $this->prepareData($Options);

        $this->sql = "INSERT INTO tbl_deliveryoption (Options) VALUES( '". $Options ."')";

        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

        //Update Delivery Option
    function updateDeliveryOption($ID ,$Options){
        $ID = $this->prepareData($ID);
        $Options = $this->prepareData($Options);

        $this->sql = "UPDATE tbl_deliveryoption SET Options = '". $Options ."' WHERE id_deliveryoption = '". $ID ."'";

        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

        //Delete Delivery Option
    function deleteDeliveryOption($ID){
        $ID = $this->prepareData($ID);

        $this->sql = "UPDATE tbl_deliveryoption SET Deleted = '1' WHERE id_deliveryoption = '". $ID ."'";

        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

        //Insert Gender
    function insertGender($Identities){
        $Identities = $this->prepareData($Identities);

        $this->sql = "INSERT INTO tbl_gender(Identities) VALUES('". $Identities."')";

        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

        //Update Gender
    function updateGender($ID ,$Identities){
        $ID = $this->prepareData($ID);
        $Identities = $this->prepareData($Identities);

        $this->sql = "UPDATE tbl_gender SET Identities ='".$Identities."' WHERE id_gender = '". $ID ."' ";

        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

        //Delete Gender
    function deleteGender($ID){
        $ID = $this->prepareData($ID);

        $this->sql = "UPDATE tbl_gender SET Deleted ='1' WHERE id_gender = '". $ID ."'";

        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }


        //Insert Certificate
    function insertCertificate($Types, $DocFee, $DeliveryFee ){
        $Types = $this->prepareData($Types);
        $DocFee = $this->prepareData($DocFee);
        $DeliveryFee = $this->prepareData($DeliveryFee);

        $this->sql = "INSERT INTO tbl_certificate(Types, DocFee, DeliveryFee) VALUES('". $Types."', '". $DocFee ."', '". $DeliveryFee ."' )";

        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

        //update Certificate
    function updateCertificate($ID , $Types, $DocFee, $DeliveryFee ){
        $ID = $this->prepareData($ID);
        $Types = $this->prepareData($Types);
        $DocFee = $this->prepareData($DocFee);
        $DeliveryFee = $this->prepareData($DeliveryFee);

        $this->sql = "UPDATE tbl_certificate SET Types='". $Types ."', DocFee= '".$DocFee."', DeliveryFee='".$DeliveryFee."' WHERE id_certificate='".$ID."'";

        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

        //Delete Gender
    function deleteCertificate($ID){
        $ID = $this->prepareData($ID);

        $this->sql = "UPDATE tbl_certificate SET Deleted ='1' WHERE id_certificate = '". $ID ."'";

        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

}
?>
