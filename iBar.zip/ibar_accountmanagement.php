<?php
require "DataBaseConfig.php";

$dbc = new DataBaseConfig();
$host = $dbc->servername;
$user = $dbc->username;
$pwd = $dbc->password;
$db = $dbc->databasename;

$conn = mysqli_connect($host, $user, $pwd, $db);
if (!$conn) {
    die("Error in Connection: " . mysqli_connect_error());
}
$response = array();
$sql_query = "SELECT a.id_account, a.Username, r.Fname, r.Mname, r.Lname ,r.Sname,IF(r.VoterStatus='Yes', 'Registered', 'Not-Registered') AS VoterStatus, a.Status , COALESCE(a.Valid, 0) AS Valid
                FROM tbl_account AS a 
                INNER JOIN tbl_residentinfo AS r ON r.id_resident = a.id_resident
                LEFT JOIN tbl_validation AS v ON v.id_validation = a.id_validation";

$result = mysqli_query($conn, $sql_query);

if (mysqli_num_rows($result) > 0) {
    $response['success'] = 1;
    $account = array();
    while ($row = mysqli_fetch_assoc($result)) {
        array_push($account, $row);
    }
    $response['account'] = $account;
} else {
    $response['success'] = 0;
    $response['message'] = 'No Data';
}
echo json_encode($response);
mysqli_close($conn);
?>