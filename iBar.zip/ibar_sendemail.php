<?php
    // if ($_SERVER["REQUEST_METHOD"] == "POST") {
    //     if(isset($_POST['Email']) && isset($_POST['Code'])){

    //         $Email = $_POST['Email'];
    //         $Code = $_POST['Code'];

    require 'C:/xampp/phpMyAdmin/vendor/autoload.php';
    require 'EmailConfig.php';

    
    $econfig = new EmailConfig();

    $sendgridApiKey = $econfig->sendgridApiKey;
    $sendgridApiEmail = $econfig->sendgridApiEmail;

    $sendgrid = new SendGrid($sendgridApiKey);
    $email    = new SendGrid\Email();
    
    $email->addTo("thisismenoli11@gmail.com")
          ->setFrom("sti_ibarangay@outlook.com")
          ->setSubject("Sending with SendGrid is Fun")
          ->setHtml("and easy to do anywhere, even with PHP");
    
    $sendgrid->send($email);
        // }else{
        // }
    //}
?>