<?php
require "DataBaseConfig.php";

$dbc = new DataBaseConfig();
$host = $dbc->servername;
$user = $dbc->username;
$pwd = $dbc->password;
$db = $dbc->databasename;

$conn = mysqli_connect($host, $user, $pwd, $db);
if (!$conn) {
    die("Error in Connection: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ID = $_POST['ID'];
    if(isset($_POST['ID'])){
        $response = array();
        
        $sql_query = "SELECT ser.id_misservices, i.ItemName , ser.Quantity, ser.DateOfRequest, ser.Status, 
        DATE_FORMAT(ser.Deadline, \" %Y-%m-%d\") AS Deadline, RentDate, d.Options
        FROM tbl_misservices AS ser 
        INNER JOIN tbl_account AS a ON a.id_account = ser.id_account 
        INNER JOIN tbl_items AS i ON i.id_items = ser.id_items
        LEFT JOIN tbl_deliveryoption AS d ON d.id_deliveryoption = ser.id_deliveryoption 
        WHERE a.id_account='". $ID ."'";
        
        $result = mysqli_query($conn, $sql_query);

        if (mysqli_num_rows($result) > 0) {
            $response['success'] = 1;
            $service = array();
            while ($row = mysqli_fetch_assoc($result)) {
                array_push($service, $row);
            }
            $response['service'] = $service;
        } else {
            $response['success'] = 0;
            $response['message'] = 'No Data';
        }
        echo json_encode($response);
    }
    
}
else{
        $response['success'] = 0;
        $response['message'] = 'All Fields Required';
}
mysqli_close($conn);
?>