<?php
require "DataBase.php";
$db = new DataBase();
if ( !empty($_POST['ID']) && isset($_POST['Fname']) && isset($_POST['Mname']) && isset($_POST['Lname'] ) && isset($_POST['Sname']) 
    && isset($_POST['Birthplace']) && isset($_POST['Birthdate']) && isset($_POST['CivilStatus']) && isset($_POST['Gender']) 
    && isset($_POST['id_purok']) && isset($_POST['VoterStatus']) && isset($_POST['DateOfRegistration']) && isset($_POST['ContactNo']) 
    && isset($_POST['CedulaNo']) && isset($_POST['Email']) && isset($_POST['Image']) && isset($_POST['HouseAndStreet']) ) {

    if ($db->dbConnect()) {
        if ($db->updateResidentInfo( $_POST['ID'] ,$_POST['Fname'], $_POST['Mname'], $_POST['Lname'] , $_POST['Sname'], 
            $_POST['Birthplace'], $_POST['Birthdate'], $_POST['CivilStatus'] , $_POST['Gender'], $_POST['id_purok'], $_POST['VoterStatus'] , 
            $_POST['DateOfRegistration'], $_POST['ContactNo'], $_POST['CedulaNo'], $_POST['Email'] , $_POST['Image'] , $_POST['HouseAndStreet'])) {

            echo "Operation Success";

        } else echo "Operation Failed";

    } else echo "Error: Database connection";
} else echo "All fields are required";
?>
