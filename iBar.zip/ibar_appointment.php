<?php
require "DataBaseConfig.php";

$dbc = new DataBaseConfig();
$host = $dbc->servername;
$user = $dbc->username;
$pwd = $dbc->password;
$db = $dbc->databasename;

$conn = mysqli_connect($host, $user, $pwd, $db);
if (!$conn) {
    die("Error in Connection: " . mysqli_connect_error());
}
$response = array();
$sql_query = "SELECT id_appointment, Title, Name, Date, StartTime, EndTime, Status, Details FROM tbl_appointment 
                WHERE Deleted =0 GROUP BY Title, Name,Details,StartTime,EndTime";

$result = mysqli_query($conn, $sql_query);

if (mysqli_num_rows($result) > 0) {
    $response['success'] = 1;
    $appointment = array();
    while ($row = mysqli_fetch_assoc($result)) {
        array_push($appointment, $row);
    }
    $response['appointment'] = $appointment;
} else {
    $response['success'] = 0;
    $response['message'] = 'No Data';
}
echo json_encode($response);
mysqli_close($conn);
?>