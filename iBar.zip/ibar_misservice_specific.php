<?php
require "DataBaseConfig.php";

$dbc = new DataBaseConfig();
$host = $dbc->servername;
$user = $dbc->username;
$pwd = $dbc->password;
$db = $dbc->databasename;

$conn = mysqli_connect($host, $user, $pwd, $db);
if (!$conn) {
    die("Error in Connection: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ID = $_POST['ID'];
    if(isset($_POST['ID'])){
        $response = array();
        
        $sql_query = "SELECT i.ItemName , ser.Quantity, ser.Purpose, ser.DateOfRequest, ser.Deadline, ser.Status, ser.Note , ser.RentDate,  d.Options, a.Username, r.Email,
        CONCAT(r.Fname,' ',r.Mname,' ', r.Lname,' ', r.Sname) AS Fullname, ContactNo, CedulaNo, IF(VoterStatus='Yes', 'Registered', 'Not-Registered') AS VoterStatus, r.HouseNoAndStreet,
        (SELECT COUNT(id_assailant_resident) FROM tbl_assailantresident WHERE id_resident =r.id_resident AND Deleted =0) AS Blotter
        FROM tbl_misservices AS ser 
        INNER JOIN tbl_items AS i ON i.id_items = ser.id_items 
        INNER JOIN tbl_deliveryoption AS d ON d.id_deliveryoption = ser.id_deliveryoption 
        LEFT JOIN tbl_account AS a ON a.id_account = ser.id_account
        LEFT JOIN tbl_residentinfo AS r ON r.id_resident = a.id_resident
        WHERE ser.id_misservices = '" . $ID . "' 
        LIMIT 0,1";
        
        $result = mysqli_query($conn, $sql_query);

        if (mysqli_num_rows($result) > 0) {
            $response['success'] = 1;
            $service = array();
            while ($row = mysqli_fetch_assoc($result)) {
                array_push($service, $row);
            }
            $response['service'] = $service;
        } else {
            $response['success'] = 0;
            $response['message'] = 'No Data';
        }
        echo json_encode($response);
    }
    
}
else{
        $response['success'] = 0;
        $response['message'] = 'All Fields Required';
}
mysqli_close($conn);
?>