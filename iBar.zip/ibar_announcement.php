<?php
require "DataBaseConfig.php";

$dbc = new DataBaseConfig();
$host = $dbc->servername;
$user = $dbc->username;
$pwd = $dbc->password;
$db = $dbc->databasename;

$conn = mysqli_connect($host, $user, $pwd, $db);
if (!$conn) {
    die("Error in Connection: " . mysqli_connect_error());
}
$response = array();
$sql_query = "SELECT a.id_announcement, a.Date, a.Subject, a.Level, l.ImageLocation, a.Details FROM tbl_announcement AS a INNER JOIN tbl_alertlevel AS l ON l.id_alertlevel = a.id_alertlevel WHERE a.Deleted = 0 ORDER BY Date DESC";
$result = mysqli_query($conn, $sql_query);

if (mysqli_num_rows($result) > 0) {
    $response['success'] = 1;
    $announcement = array();
    while ($row = mysqli_fetch_assoc($result)) {
        array_push($announcement, $row);
    }
    $response['announcement'] = $announcement;
} else {
    $response['success'] = 0;
    $response['message'] = 'No Data';
}
echo json_encode($response);
mysqli_close($conn);
?>