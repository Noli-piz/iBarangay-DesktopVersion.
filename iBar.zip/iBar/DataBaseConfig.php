<?php

class DataBaseConfig
{
    public $servername;
    public $username;
    public $password;
    public $databasename;

    public function __construct()
    {

        // $this->servername = 'localhost';
        // $this->username = 'root';
        // $this->password = '';
        // $this->databasename = 'ibarangaydb';

       $this->servername = 'sql6.freemysqlhosting.net';
       $this->username = 'sql6439916';
       $this->password = 'pU3V3LZ6vd';
       $this->databasename = 'sql6439916';

    // $this->servername = 'ibarangayserver.mysql.database.azure.com';
    // $this->username = 'ibarangay_admin@ibarangayserver';
    // $this->password = 'iBar123@';
    // $this->databasename = 'ibarangaydb';
    }
}

?>
