<?php
require "DataBase.php";
$db = new DataBase();

if (isset($_POST['UserID']) && isset($_POST['Types']) && isset($_POST['ResidentID']) && isset($_POST['Purpose'])) {
    if ($db->dbConnect()) {
        if ($db->insertIssuanceReports($_POST['UserID'], $_POST['Types'], $_POST['ResidentID'], $_POST['Purpose'])) {
            echo "Operation Success";
        } else echo "Operation Failed";
    } else echo "Error: Database connection";
} else echo "All fields are required";

?>
