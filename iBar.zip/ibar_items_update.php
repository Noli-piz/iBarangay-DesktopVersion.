<?php
require "DataBase.php";
$db = new DataBase();

if (isset($_POST['ID'], $_POST['Items']) && isset($_POST['Quantity']) && isset($_POST['DeliveryFee'])) {
    if ($db->dbConnect()) {
        if ($db->updateItems($_POST['ID'] ,$_POST['Items'], $_POST['Quantity'], $_POST['DeliveryFee'])) {
            echo "Operation Success";
        } else echo "Operation Failed";
    } else echo "Error: Database connection";
} else echo "All fields are required";

?>
