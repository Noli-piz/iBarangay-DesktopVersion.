<?php
require "DataBaseConfig.php";

$dbc = new DataBaseConfig();
$host = $dbc->servername;
$user = $dbc->username;
$pwd = $dbc->password;
$db = $dbc->databasename;

$conn = mysqli_connect($host, $user, $pwd, $db);
if (!$conn) {
    die("Error in Connection: " . mysqli_connect_error());
}
$response = array();
$Username = $_GET['Username'];

$sql_query = "SELECT i.ItemName, m.Quantity , m.Purpose, m.DateOfRequest, m.Status , d.Options FROM tbl_misservices AS m INNER JOIN tbl_items AS i ON i.id_items = m.id_items INNER JOIN tbl_deliveryoption AS d ON d.id_deliveryoption = m.id_deliveryoption WHERE m.id_account = (SELECT id_account FROM tbl_account WHERE Username = '" . $Username . "') AND m.Status = 'Barrowed';";


$result = mysqli_query($conn, $sql_query);

if (mysqli_num_rows($result) > 0) {
    $response['success'] = 1;
    $service = array();
    while ($row = mysqli_fetch_assoc($result)) {
        array_push($service, $row);
    }
    $response['service'] = $service;
} else {
    $response['success'] = 0;
    $response['message'] = 'No Data';
}
echo json_encode($response);
mysqli_close($conn);
?>
