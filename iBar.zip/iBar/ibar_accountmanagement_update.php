<?php
require "DataBase.php";
$db = new DataBase();

if (isset($_POST['Username']) && isset($_POST['Password']) && isset($_POST['Status']) && isset($_POST['ID']) && isset($_POST['Valid'])) {
    if ($db->dbConnect()) {
        if ($db->updateAccount($_POST['Username'],  $_POST['Password'], $_POST['Status'], $_POST['ID'], $_POST['Valid']) ) {
            echo "Operation Success";
        } else echo "Operation Failed";
    } else echo "Error: Database connection";
} else echo "All fields are required";
?>
