<?php

class DataBaseConfig
{
    public $servername;
    public $username;
    public $password;
    public $databasename;

    public function __construct()
    {

        $this->servername = 'localhost';
        $this->username = 'root';
        $this->password = '';
        $this->databasename = 'ibarangaydb';

//        $this->servername = 'sql6.freemysqlhosting.net';
//        $this->username = 'sql6427233';
//        $this->password = 'V99HzU9dpl';
//        $this->databasename = 'sql6427233';
    }
}

?>
