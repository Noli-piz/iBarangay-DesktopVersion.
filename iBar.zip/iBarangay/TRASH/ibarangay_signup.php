<?php
require "DataBase.php";
$db = new DataBase();
if (isset($_POST['Username']) && isset($_POST['Password']) && isset($_POST['Email'] ) && isset($_POST['Status'])) {
    if ($db->dbConnect()) {
        if ($db->isignUp( $_POST['Username'], $_POST['Password'], $_POST['Email'] , $_POST['Status'])) {
            echo "Sign Up Success";
        } else echo "Sign up Failed";
    } else echo "Error: Database connection";
} else echo "All fields are required";
?>
