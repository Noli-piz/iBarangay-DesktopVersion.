<?php
    // if ($_SERVER["REQUEST_METHOD"] == "POST") {
    //     if(isset($_POST['Email']) && isset($_POST['Code'])){

    //         $Email = $_POST['Email'];
    //         $Code = $_POST['Code'];

            $to      = "thisismenoli11@gmail.com";
            $subject = 'Verification Code.';
            $message = 'Your verification code is ' ;
            $headers = 'From: noreply@ibarangay.com'       . "\r\n" .
                        'Reply-To: webmaster@example.com' . "\r\n" .
                        'X-Mailer: PHP/' . phpversion();

            mail($to, $subject, $message, $headers);
        // }else{
        // }
    //}
?>