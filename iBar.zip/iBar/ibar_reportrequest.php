<?php
require "DataBaseConfig.php";

$dbc = new DataBaseConfig();
$host = $dbc->servername;
$user = $dbc->username;
$pwd = $dbc->password;
$db = $dbc->databasename;

$conn = mysqli_connect($host, $user, $pwd, $db);
if (!$conn) {
    die("Error in Connection: " . mysqli_connect_error());
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $Date1 = $_POST['Date1'];
    $Date2 = $_POST['Date2'];

    $response = array();
    $sql_query = "SELECT rep.id_requestsreports , u.Fullname, a.Username, res.Fname, res.Mname, res.Lname, res.Sname ,r.Purpose, r.DateOfRequest ,r.Status ,d.Options, rep.Date 
                    FROM tbl_requestsreports AS rep
                    LEFT JOIN tbl_users AS u ON u.id_users = rep.id_users
                    LEFT JOIN tbl_request AS r ON r.id_request = rep.id_request
                    LEFT JOIN tbl_account AS a ON a.id_account = r.id_account
                    LEFT JOIN tbl_certificate AS c ON c.id_certificate = r.id_certificate
                    LEFT JOIN tbl_deliveryoption AS d ON d.id_deliveryoption = r.id_deliveryoption
                    LEFT JOIN tbl_residentinfo as res ON res.id_resident = a.id_resident
                    WHERE rep.Date >= '". $Date1 ."' AND rep.Date <= '" . $Date2 . "'";

    $result = mysqli_query($conn, $sql_query);

    if (mysqli_num_rows($result) > 0) {
        $response['success'] = 1;
        $requestreport = array();
        while ($row = mysqli_fetch_assoc($result)) {
            array_push($requestreport, $row);
        }
        $response['requestreport'] = $requestreport;
    } else {
        $response['success'] = 0;
        $response['message'] = 'No Data';
    }
}
else {
    $response['success'] = 0;
    $response['message'] = 'All data is required.';
}

echo json_encode($response);
mysqli_close($conn);
?>