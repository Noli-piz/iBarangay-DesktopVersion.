<?php
require "DataBase.php";
$db = new DataBase();
if ($db->dbConnect()) {
    if ($db->icertificate()) {
        echo "Retrieve Success";
    } else echo "All data collected";
} else echo "Error: Database connection";
?>
