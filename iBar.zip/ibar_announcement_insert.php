<?php
require "DataBase.php";
$db = new DataBase();

if (isset($_POST['Subject']) && isset($_POST['Details']) && isset($_POST['Date']) && isset($_POST['Level']) && isset($_POST['UserID'])) {
    if ($db->dbConnect()) {
        if ($db->insertAnnouncement($_POST['Subject'], $_POST['Details'], $_POST['Date'], $_POST['Level'], $_POST['UserID'])) {
            echo "Operation Success";
        } else echo "Operation Failed";
    } else echo "Error: Database connection";
} else echo "All fields are required";
?>
