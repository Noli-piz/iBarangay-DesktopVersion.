<?php
require "DataBaseConfig.php";

$dbc = new DataBaseConfig();
$host = $dbc->servername;
$user = $dbc->username;
$pwd = $dbc->password;
$db = $dbc->databasename;

$conn = mysqli_connect($host, $user, $pwd, $db);
if (!$conn) {
    die("Error in Connection: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ID = $_POST['ID'];
    $Category = $_POST['Category'];

    if(isset($_POST['ID']) && isset($_POST['Category'])){
        $response = array();
        $sql_query = "SELECT a.id_account, a.Username, r.Fname, r.Mname, r.Lname ,r.Sname, r.VoterStatus, a.Status FROM tbl_account AS a 
            INNER JOIN tbl_residentinfo AS r ON r.id_resident = a.id_resident";


         if($Category== "Fullname"){
            $sql_query = "SELECT a.id_account, a.Username, r.Fname, r.Mname, r.Lname ,r.Sname, r.VoterStatus, a.Status FROM tbl_account AS a 
                INNER JOIN tbl_residentinfo AS r ON r.id_resident = a.id_resident
                WHERE r.Fname LIKE '%". $ID ."' OR r.Mname LIKE '%". $ID ."' OR r.Lname LIKE '%". $ID ."' ";

         }elseif($Category == "ID"){
            $sql_query = "SELECT a.id_account, a.Username, r.Fname, r.Mname, r.Lname ,r.Sname, r.VoterStatus, a.Status FROM tbl_account AS a 
                INNER JOIN tbl_residentinfo AS r ON r.id_resident = a.id_resident
                WHERE a.id_account = '". $ID ."' ";

         }elseif($Category == "Username"){
            $sql_query = "SELECT a.id_account, a.Username, r.Fname, r.Mname, r.Lname ,r.Sname, r.VoterStatus, a.Status FROM tbl_account AS a 
                INNER JOIN tbl_residentinfo AS r ON r.id_resident = a.id_resident 
                WHERE a.Username LIKE '%". $ID ."' ";

         }


        $result = mysqli_query($conn, $sql_query);

        if (mysqli_num_rows($result) > 0) {
            $response['success'] = 1;
            $account = array();
            while ($row = mysqli_fetch_assoc($result)) {
                array_push($account, $row);
            }
            $response['account'] = $account;
        } else {
            $response['success'] = 0;
            $response['message'] = 'No Result';
        }
        echo json_encode($response);
    }
    
}
else{
        $response['success'] = 0;
        $response['message'] = 'All Fields Required';
}
mysqli_close($conn);
?>