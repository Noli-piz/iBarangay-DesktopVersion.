<?php
require "DataBaseConfig.php";

$dbc = new DataBaseConfig();
$host = $dbc->servername;
$user = $dbc->username;
$pwd = $dbc->password;
$db = $dbc->databasename;

$conn = mysqli_connect($host, $user, $pwd, $db);
if(!$conn){
    die("Error in Connection: " . mysqli_connect_error());
}
$Username = $_GET['Username'];
$response = array();
$sql_query = "SELECT r.Fname, r.Mname, r.Lname, r.Sname, r.Image, r.Birthplace, YEAR(r.Birthdate) AS BYear, MONTH(r.Birthdate) AS BMonth, DAY(r.Birthdate) AS BDay, 
                r.CivilStatus, r.Gender, YEAR(r.DateOfRegistration) AS RYear,MONTH(r.DateOfRegistration) AS RMonth,DAY(r.DateOfRegistration) AS RDay, r.ContactNo, r.CedulaNo, 
                COALESCE(a.Valid, 0) AS Valid
                FROM tbl_residentinfo  AS r 
                LEFT JOIN tbl_account AS a ON a.id_resident = r.id_resident
                LEFT JOIN tbl_validation AS v ON v.id_validation = a.id_validation
                WHERE r.id_resident = (SELECT id_resident FROM tbl_account WHERE Username = '". $Username ."'); ";


$result = mysqli_query($conn, $sql_query);

if(mysqli_num_rows($result) > 0){
    $response['success'] = 1;
    $info = array();
    while ($row = mysqli_fetch_assoc($result)){
        array_push($info, $row);
    }
    $response['info'] = $info;
}else{
    $response['success'] = 0;
    $response['message'] = 'No Data';
}
echo json_encode($response);
mysqli_close($conn);
?>
