<?php
require "DataBase.php";
$db = new DataBase();

if ( isset($_POST['ID']) && isset($_POST['Subject']) && isset($_POST['Details']) && isset($_POST['Date']) && isset($_POST['Level'])) {
    if ($db->dbConnect()) {
        if ($db->updateAnnouncement($_POST['ID'], $_POST['Subject'], $_POST['Details'], $_POST['Date'], $_POST['Level'])) {
            echo "Operation Success";
        } else echo "Operation Failed";
    } else echo "Error: Database connection";
} else echo "All fields are required";
?>
