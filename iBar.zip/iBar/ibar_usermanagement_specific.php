<?php
require "DataBaseConfig.php";

$dbc = new DataBaseConfig();
$host = $dbc->servername;
$user = $dbc->username;
$pwd = $dbc->password;
$db = $dbc->databasename;

$conn = mysqli_connect($host, $user, $pwd, $db);
if (!$conn) {
    die("Error in Connection: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ID = $_POST['ID'];
    if(isset($_POST['ID'])){

        $response = array();
        $sql_query = "SELECT Username, Password, Fullname, Status, LevelOfAccess FROM tbl_users WHERE id_users = '".$ID."'";
        
        $result = mysqli_query($conn, $sql_query);

        if (mysqli_num_rows($result) > 0) {
            $response['success'] = 1;
            $users = array();
            while ($row = mysqli_fetch_assoc($result)) {
                array_push($users, $row);
            }
            $response['users'] = $users;
        } else {
            $response['success'] = 0;
            $response['message'] = 'No Data';
        }
        echo json_encode($response);
    }
    
}
else{
        $response['success'] = 0;
        $response['message'] = 'All Fields Required';
}
mysqli_close($conn);
?>