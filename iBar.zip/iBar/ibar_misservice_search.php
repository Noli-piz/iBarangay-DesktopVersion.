<?php
require "DataBaseConfig.php";

$dbc = new DataBaseConfig();
$host = $dbc->servername;
$user = $dbc->username;
$pwd = $dbc->password;
$db = $dbc->databasename;

$conn = mysqli_connect($host, $user, $pwd, $db);
if (!$conn) {
    die("Error in Connection: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ID = $_POST['ID'];
    $Category = $_POST['Category'];

    if(isset($_POST['ID']) && isset($_POST['Category'])){
        $response = array();

        $sql_query = "SELECT ser.id_misservices, res.Fname, res.Mname, res.Lname, res.Sname, res.Birthdate, res.VoterStatus, i.ItemName , ser.Quantity, ser.DateOfRequest, ser.Status, DATE_FORMAT(ser.Deadline, \" %Y-%m-%d\") AS Date FROM tbl_misservices AS ser 
        INNER JOIN tbl_account AS a ON a.id_account = ser.id_account 
        INNER JOIN tbl_residentinfo AS res ON res.id_resident = a.id_resident 
        INNER JOIN tbl_items AS i ON i.id_items = ser.id_items";

         if($Category== "Name"){
            $sql_query = $sql_query . " WHERE res.Fname LIKE '". $ID ."' OR res.Mname LIKE '". $ID ."' OR res.Lname LIKE '". $ID ."' ";

         }elseif($Category == "ID"){
            $sql_query = $sql_query . " WHERE ser.id_misservices = '". $ID ."'";
         }


        $result = mysqli_query($conn, $sql_query);

        if (mysqli_num_rows($result) > 0) {
            $response['success'] = 1;
            $service = array();
            while ($row = mysqli_fetch_assoc($result)) {
                array_push($service, $row);
            }
            $response['service'] = $service;
        } else {
            $response['success'] = 0;
            $response['message'] = 'No Result';
        }
        echo json_encode($response);
    }
    
}
else{
        $response['success'] = 0;
        $response['message'] = 'All Fields Required';
}
mysqli_close($conn);
?>