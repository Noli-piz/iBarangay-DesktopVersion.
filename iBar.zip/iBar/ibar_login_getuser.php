<?php
require "DataBaseConfig.php";

$dbc = new DataBaseConfig();
$host = $dbc->servername;
$user = $dbc->username;
$pwd = $dbc->password;
$db = $dbc->databasename;

$conn = mysqli_connect($host, $user, $pwd, $db);
if (!$conn) {
    die("Error in Connection: " . mysqli_connect_error());
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $Username = $_POST['Username'];
    
    $response = array();
    $sql_query = "SELECT id_users, Username, Fullname FROM tbl_users WHERE Status = '0' AND Username = '". $Username ."' LIMIT 1";


    $result = mysqli_query($conn, $sql_query);

    if (mysqli_num_rows($result) > 0) {
        $response['success'] = 1;
        $userlogin = array();
        while ($row = mysqli_fetch_assoc($result)) {
            array_push($userlogin, $row);
        }
        $response['userlogin'] = $userlogin;
    } else {
        $response['success'] = 0;
        $response['message'] = 'No Data';
    }
}
else {
    $response['success'] = 0;
    $response['message'] = 'All data is required.';
}
echo json_encode($response);
mysqli_close($conn);
?>