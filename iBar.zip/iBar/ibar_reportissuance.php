<?php
require "DataBaseConfig.php";

$dbc = new DataBaseConfig();
$host = $dbc->servername;
$user = $dbc->username;
$pwd = $dbc->password;
$db = $dbc->databasename;

$conn = mysqli_connect($host, $user, $pwd, $db);
if (!$conn) {
    die("Error in Connection: " . mysqli_connect_error());
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $Date1 = $_POST['Date1'];
    $Date2 = $_POST['Date2'];


    $response = array();
    $sql_query = "SELECT i.id_issuancereports ,u.Fullname ,r.Fname, r.Mname, r.Lname, r.Sname, c.Types ,i.Purpose, i.Date 
                    FROM tbl_issuancereports AS i 
                    LEFT JOIN tbl_users AS u ON u.id_users = i.id_users
                    LEFT JOIN tbl_residentinfo AS r ON r.id_resident = i.id_resident
                    LEFT JOIN tbl_certificate AS c ON c.id_certificate = i.id_certificate
                    WHERE i.Date >= '". $Date1 ."' AND i.Date <= '" . $Date2 . "'";


    $result = mysqli_query($conn, $sql_query);

    if (mysqli_num_rows($result) > 0) {
        $response['success'] = 1;
        $issuancereport = array();
        while ($row = mysqli_fetch_assoc($result)) {
            array_push($issuancereport, $row);
        }
        $response['issuancereport'] = $issuancereport;
    } else {
        $response['success'] = 0;
        $response['message'] = 'No Data';
    }
}
else {
    $response['success'] = 0;
    $response['message'] = 'All data is required.';
}
echo json_encode($response);
mysqli_close($conn);
?>