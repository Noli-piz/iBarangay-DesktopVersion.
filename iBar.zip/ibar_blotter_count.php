<?php
require "DataBaseConfig.php";

$dbc = new DataBaseConfig();
$host = $dbc->servername;
$user = $dbc->username;
$pwd = $dbc->password;
$db = $dbc->databasename;

$conn = mysqli_connect($host, $user, $pwd, $db);
if (!$conn) {
    die("Error in Connection: " . mysqli_connect_error());
}

    $response = array();
    $sql_query = "SELECT (SELECT COUNT(*) FROM tbl_blotterinfo WHERE Status = 'Active') AS Active,
                        (SELECT COUNT(*) FROM tbl_blotterinfo WHERE Status = 'Settled') AS Settled,
                        (SELECT COUNT(*) FROM tbl_blotterinfo WHERE Status = 'Scheduled') AS Scheduled
                        FROM tbl_blotterinfo LIMIT 1";

    $result = mysqli_query($conn, $sql_query);

    if (mysqli_num_rows($result) > 0) {
        $response['success'] = 1;
        $count = array();
        while ($row = mysqli_fetch_assoc($result)) {
            array_push($count, $row);
        }
        $response['count'] = $count;
    } else {
        $response['success'] = 0;
        $response['message'] = 'No Data';
    }
    echo json_encode($response);

mysqli_close($conn);
?>