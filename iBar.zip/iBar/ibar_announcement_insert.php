<?php
require "DataBase.php";
$db = new DataBase();

if (isset($_POST['Subject']) && isset($_POST['Details']) && isset($_POST['Date']) && isset($_POST['Level'])) {
    if ($db->dbConnect()) {
        if ($db->insertAnnouncement($_POST['Subject'], $_POST['Details'], $_POST['Date'], $_POST['Level'])) {
            echo "Operation Success";
        } else echo "Operation Failed";
    } else echo "Error: Database connection";
} else echo "All fields are required";
?>
