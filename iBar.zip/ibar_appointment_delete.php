<?php
require "DataBase.php";
$db = new DataBase();

// if (isset($_POST['ID']) && isset($_POST['UserID'])) {
//     if ($db->dbConnect()) {
//         if ($db->deleteAppointment($_POST['ID'], $_POST['UserID'] )) {
//             echo "Operation Success";
//         } else echo "Operation Failed";
//     } else echo "Error: Database connection";
// } else echo "All fields are required";

if (isset($_POST['content']) && isset($_POST['UserID']) && isset($_POST['StartTimeFilter']) && isset($_POST['EndTimeFilter'])) {
    if ($db->dbConnect()) {
        if ($db->deleteAppointment($_POST['content'], $_POST['UserID'], $_POST['StartTimeFilter'], $_POST['EndTimeFilter'] )) {
            echo "Operation Success";
        } else echo "Operation Failed";
    } else echo "Error: Database connection";
} else echo "All fields are required";

?>
