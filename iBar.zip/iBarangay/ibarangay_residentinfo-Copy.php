<?php

require "DataBaseConfig.php";

$dbc = new DataBaseConfig();
$host = $dbc->servername;
$user = $dbc->username;
$pwd = $dbc->password;
$db = $dbc->databasename;


$conn = mysqli_connect($host, $user, $pwd, $db);
if(!$conn){
    die("Error in Connection: " . mysqli_connect_error());
}
//$id = $_GET['id'];
$id =1;
$response = array();
$sql = "";
$result = mysqli_query($conn,"SELECT * FROM tbl_residentinfo WHERE id_resident = (SELECT id_resident FROM tbl_account  WHERE id_resident = '$id')");

if(mysqli_num_rows($result) > 0){
    $response['success'] = 1;
    $certificate = array();
    while ($row = mysqli_fetch_assoc($result)){
        array_push($certificate, $row);
    }
    $response['certificate'] = $certificate;
}
else{
    $response['success'] = 0;
    $response['message'] = 'No Data';
}
echo json_encode($response);
mysqli_close($conn);
?>