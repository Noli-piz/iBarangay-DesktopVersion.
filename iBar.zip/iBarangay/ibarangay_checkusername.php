<?php
require "DataBase.php";
$db = new DataBase();

if (isset($_POST['Username'])) {
    if ($db->dbConnect()) {
        if ($db->checkUsername($_POST['Username'])){
            echo "Username is Available";
        } else echo "Username already Exist!";
    } else echo "Error: Database connection";
} else echo "All fields are required";
?>
